<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <h2 class="font-semibold text-xl text-gray-800 leading-tight">
            <?php echo e(__('Verifikasi Penjamu')); ?>

        </h2>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900">
                    <table id="example" class="display" style="width:100%">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>ID</th>
                            <th>NIM</th>
                            <th>Nama</th>
                            <th>Phone/Whatsapp</th>
                            <th>Verified</th>
                            <th>Status</th>
                            <th>Problem</th>
                            <th>Action</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $penjamus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penjamu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e($penjamu['id']); ?></td>
                                <td><?php echo e($penjamu['nim']); ?></td>
                                <td><?php echo e($penjamu['name']); ?></td>
                                <td><?php echo e($penjamu['phone']); ?></td>
                                <td><?php echo e($penjamu['is_verified'] === null?"NOT ACTIVATED":($penjamu['is_verified']?"ACCEPTED":"DECLINED")); ?></td>
                                <td><?php echo e($penjamu['is_activated'] === false ? "DEACTIVE":""); ?></td>
                                <td><?php echo e($penjamu['is_problem']); ?></td>
                                <td>
                                    <!-- Button trigger modal -->
                                    <?php if( $penjamu['is_verified'] === null): ?>
                                    <button type="button" class="btn btn-outline-primary" data-toggle="modal"
                                            data-target="#verifyModal-<?php echo e($penjamu['id']); ?>">
                                        Verifikasi
                                    </button>
                                    <?php endif; ?>

                                    <?php if( $penjamu['is_activated'] !== false): ?>
                                    <button type="button" class="btn btn-outline-danger" data-toggle="modal"
                                            data-target="#deactivateModal-<?php echo e($penjamu['id']); ?>">
                                        Deactivate
                                    </button>
                                    <?php else: ?>
                                        <button type="button" class="btn btn-outline-success" data-toggle="modal"
                                                data-target="#activateModal-<?php echo e($penjamu['id']); ?>">
                                            Activate
                                        </button>
                                    <?php endif; ?>

                                    <!-- Modal -->
                                    <div class="modal fade" id="verifyModal-<?php echo e($penjamu['id']); ?>" tabindex="-1" role="dialog"
                                         aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Verifikasi Penjamu</h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <img src="https://assets-global.website-files.com/64abfb060667e3285fe19983/64f00ba612b2fd18a68dd1c7_contoh%20KTM.jpeg" width="600" height="auto" alt="FOTO KTM"/>

                                                    <div class="row mt-4">
                                                        <div class="col text-left">
                                                            <form method="POST" action="<?php echo e(route('decline.penjamu', ['id' => $penjamu['id']])); ?>">
                                                                <?php echo csrf_field(); ?>
                                                                <button type="submit" class="btn btn-outline-danger">Decline</button>
                                                            </form>
                                                        </div>
                                                        <div class="col text-right">
                                                            <form method="POST" action="<?php echo e(route('accept.penjamu', ['id' => $penjamu['id']])); ?>">
                                                                <?php echo csrf_field(); ?>
                                                                <button type="submit" class="btn btn-outline-success">Accept</button>
                                                            </form>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="modal fade" id="deactivateModal-<?php echo e($penjamu['id']); ?>" tabindex="-1" role="dialog"
                                         aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Konfirmasi Deactivate Penjamu</h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <p>Apakah kamu yakin ingin menonaktifkan akun penjamu ini?</p>
                                                    <p><b>Problem:</b></p>
                                                </div>
                                                <div class="modal-footer">
                                                    <form method="POST" action="<?php echo e(route('deactive.penjamu', ['id' => $penjamu['id']])); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <button type="submit" class="btn btn-outline-danger">Deactivate</button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="modal fade" id="activateModal-<?php echo e($penjamu['id']); ?>" tabindex="-1" role="dialog"
                                         aria-labelledby="exampleModalLabel" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="exampleModalLabel">Konfirmasi Activate Penjamu</h5>
                                                    <button type="button" class="close" data-dismiss="modal"
                                                            aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <p>Apakah kamu yakin ingin mengaktifkan kembali akun penjamu ini?</p>
                                                </div>
                                                <div class="modal-footer">
                                                    <form method="POST" action="<?php echo e(route('active.penjamu', ['id' => $penjamu['id']])); ?>">
                                                        <?php echo csrf_field(); ?>
                                                        <button type="submit" class="btn btn-outline-success">Activate</button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"
            integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo"
            crossorigin="anonymous"></script>
    <script src="https://cdn.datatables.net/2.0.0/js/dataTables.min.js"></script>
    <script>

        new DataTable('#example');
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Administrator\Documents\admin-jaka\resources\views/verifikasi-penjamu.blade.php ENDPATH**/ ?>